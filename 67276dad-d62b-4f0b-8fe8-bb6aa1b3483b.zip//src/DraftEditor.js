import React, { useState, useEffect } from "react";
import {
  Editor,
  EditorState,
  RichUtils,
  Modifier,
  convertToRaw,
  convertFromRaw,
} from "draft-js";
import "draft-js/dist/Draft.css";

const styleMap = {
  RED: {
    color: "red",
  },
  UNDERLINE: {
    textDecoration: "underline",
  },
};

const DraftEditor = () => {
  const [editorState, setEditorState] = useState(() => {
    const savedData = localStorage.getItem("editorContent");
    if (savedData) {
      const contentState = convertFromRaw(JSON.parse(savedData));
      return EditorState.createWithContent(contentState);
    }
    return EditorState.createEmpty();
  });

  const handleKeyCommand = (command) => {
    const newState = RichUtils.handleKeyCommand(editorState, command);
    if (newState) {
      setEditorState(newState);
      return "handled";
    }
    return "not-handled";
  };

  const handleBeforeInput = (input) => {
    const contentState = editorState.getCurrentContent();
    const selection = editorState.getSelection();
    const blockKey = selection.getStartKey();
    const block = contentState.getBlockForKey(blockKey);
    const blockText = block.getText();

    if (
      blockText === "" &&
      (input === "#" || input === "*" || input === "**" || input === "***")
    ) {
      let style = null;
      switch (input) {
        case "#":
          style = "header-one";
          break;
        case "*":
          style = "BOLD";
          break;
        case "**":
          style = "RED";
          break;
        case "***":
          style = "UNDERLINE";
          break;
        default:
          break;
      }
      if (style) {
        handleFormatting(style);
        return "handled";
      }
    }
    return "not-handled";
  };

  const handleFormatting = (style) => {
    if (style === "header-one") {
      setEditorState(RichUtils.toggleBlockType(editorState, style));
    } else {
      setEditorState(RichUtils.toggleInlineStyle(editorState, style));
    }
  };

  const handleSave = () => {
    const contentState = editorState.getCurrentContent();
    const plainText = contentState.getPlainText(); // Get plain text

    const blob = new Blob([plainText], { type: "text/plain" }); // Set MIME type to text/plain
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "editorContent.txt"; // Save as .txt file
    a.click();
    URL.revokeObjectURL(url);

    alert("Content saved as a text file!");
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1 style={{ textAlign: "center" }}>Demo editor by &lt;Name&gt;</h1>
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <button onClick={handleSave} style={{ marginBottom: "10px" }}>
          Save
        </button>
      </div>
      <div
        style={{
          border: "1px solid cyan",
          padding: "10px",
          minHeight: "200px",
        }}
      >
        <Editor
          editorState={editorState}
          onChange={setEditorState}
          handleKeyCommand={handleKeyCommand}
          handleBeforeInput={handleBeforeInput}
          customStyleMap={styleMap} // Apply custom styles
        />
      </div>
    </div>
  );
};

export default DraftEditor;
