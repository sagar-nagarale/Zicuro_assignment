import "./styles.css";
import DraftEditor from "./DraftEditor";

export default function App() {
  return (
    <div className="App">
      <div>
        <DraftEditor />
      </div>
    </div>
  );
}
